create function obj_description(oid, name) returns text
    stable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function obj_description(oid, name) is 'get description for object id and catalog name';

alter function obj_description(oid, name) owner to postgres;

